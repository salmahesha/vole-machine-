#include "A1_T4_S28_20230171_20230188_20230577_MainUI.h"
using namespace std;
#include <iostream>
//MainUI::MainUI(Machine m)
// {
//     machine=m;
// }
bool MainUI::getFileOrinstractions()
{
    int choice;
    cout << "1.Enter instructions manually\n2.loading a program from a file\n Enter your choice\n";
    cin >> choice;
    if (choice == 1)
    {
        return false;
    }
    else if (choice == 2)
    {
        return true;
    }
    else
    {
        getFileOrinstractions();
    }
}
void MainUI::displayMenu()
{
    cout << "================== Menu ==================" << endl;
    cout << "A.Excute instruction and print IR,PC" << endl;
    cout << "B.print memory and register" << endl;
    cout<<"C.Load a new program"<<endl;
    cout << "D. Exit" << endl;
    cout << "==========================================" << endl;
}

string MainUI::inputFileName()
{
    string fileName;
    cout <<"Enter the name of the file\n";
    cin>>fileName;
    return fileName;

}

string MainUI::inputInstraction()
{
    string instructions;
    cout << "Enter instructions manually (end with 'C000'):\n";
    // cin.ignore();
    getline(cin, instructions);
    instructions.erase(remove_if(instructions.begin(), instructions.end(), ::isspace), instructions.end());

    return instructions;
}

string MainUI::inputAddress()
{
    int choice;
    string Address;
    do {
        cout << "1. Enter address in (Hexadecimal)\n2. Store in memory from (01)\n";
        cin >> choice;

        if (choice == 1) {
            cin.ignore();
            getline(cin, Address);
            return Address;
        } else if (choice == 2) {
            return "01";
        } else {
            cout << "This choice is not valid. Please try again.\n";
        }
    } while (choice != 1 && choice != 2);

    return Address; // This return is technically redundant but added for clarity.
}

char MainUI::inputChoice()
{
  char choice;
  cout <<"Enter your choice"<<endl;
  cin>>choice;
  choice=toupper(choice);
  return choice;  
}
