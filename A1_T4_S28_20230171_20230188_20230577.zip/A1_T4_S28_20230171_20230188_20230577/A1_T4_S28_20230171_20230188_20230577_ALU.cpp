#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
#include <vector>
#include <cmath>
#include <string>
#include <algorithm>
#include <cstring>
using namespace std;
int ALU::hexToDec(string hex)
{
    int base = hex.length() - 1;
    int sum = 0;
    for (int i = 0; i < hex.length(); i++)
    {
        if (hex[i] >= '0' && hex[i] <= '9')
        {
            sum += (hex[i] - '0') * pow(16, base);
        }
        else if (hex[i] >= 'A' && hex[i] <= 'F')
        {
            sum += (hex[i] - 'A' + 10) * pow(16, base);
        }
        base--;
    }
    return sum;
}

string ALU::decToHex(int dec)
{

    if (dec == 0)
    {
        return "0";
    }
    string hexadecimal;
    int remainder;
    while (dec > 0)
    {
        remainder = dec % 16;
        if (remainder < 10)
        {
            hexadecimal += char(remainder + '0');
        }
        else
        {
            hexadecimal += char(remainder - 10 + 'A');
        }
        dec /= 16;
    }
    reverse(hexadecimal.begin(), hexadecimal.end());
    return hexadecimal;
}

bool ALU::isvalid(string instruction) {
    string validElements = "123456BC";
    string hex = "0123456789ABCDEF";
    
    if (instruction.length() != 4) {
        cout << "Error: Instruction length must be 4!" << endl;
        return false;
    }
    
    if (validElements.find(instruction[0]) == string::npos) {
        cout << "Error: Invalid first character in instruction!" << endl;
        return false;
    }
    
    for (int i = 1; i < instruction.length(); i++) {
        if (hex.find(instruction[i]) == string::npos) {
            cout << "Error: Invalid character " << instruction[i] << " in instruction." << endl;
            return false;
        }
    }
    
    return true;
}


void ALU::add(string idx1, string idx2, string idx3, Register &R)
{
       unsigned int intValue1 = hexToDec(R.getCell(idx2));  // Get value from register idx2
    unsigned int intValue2 = hexToDec(R.getCell(idx3));  // Get value from register idx3

    float value1, value2;

    // Use memcpy to convert the unsigned int to a float (interpreting the bits as a float)
    memcpy(&value1, &intValue1, sizeof(value1));
    memcpy(&value2, &intValue2, sizeof(value2));

    // Perform floating-point addition
    float result = value1 + value2;

    // Convert the result back to a 32-bit integer
    unsigned int resultInt;
    memcpy(&resultInt, &result, sizeof(result));

    // Convert the result integer to hex using manual conversion
    string resultHex = decToHex(resultInt);

    // Store the result back into the register
    R.setCell(idx1, resultHex);

}
