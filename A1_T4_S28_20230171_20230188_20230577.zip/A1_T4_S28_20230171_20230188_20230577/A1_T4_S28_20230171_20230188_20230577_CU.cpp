#include "A1_T4_S28_20230171_20230188_20230577_CU.h"
#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
#include "A1_T4_S28_20230171_20230188_20230577_CPU.h"
#include <iostream>
using namespace std;
void CU::load1(string idxReg, string intMem, Register &R, Memory &M)
{
    string value = M.getCell(intMem);
    R.setCell(idxReg, value);
}

void CU::load2(string idxReg, string val, Register &R)
{
    R.setCell(idxReg, val);
}

void CU::store(string idxReg1, string addmem, Register &R, Memory &M)
{

    M.setCell(addmem, R.getCell(idxReg1));
}
void CU::move(string idxReg1, string idxReg2, Register &R)
{
    string value1 = R.getCell(idxReg1);
    R.setCell(idxReg2, value1);
    R.setCell(idxReg1, "00");
}
void CU::ADD(string idxReg1, string idxReg2, string idxReg3, Register &R)
{
    string val1 = R.getCell(idxReg2);
    string val2 = R.getCell(idxReg3);

    int intVal1 = stoi(val1);
    int intVal2 = stoi(val2);

    int result = intVal1 + intVal2;

    string resultStr = to_string(result);

    R.setCell(idxReg1, resultStr);
}
void CU::jump(string idxReg, string stringMem, Register &R)
{
    CPU cpu;
    if (R.getCell(idxReg) == R.getCell("0")) {
        
        cpu.getPC() = stringMem; 
        
    }
}

void CU::halt()
{

    cout << "Program halted." << endl;
    
}
