#include "A1_T4_S28_20230171_20230188_20230577_Memory.h"
#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
#include <iostream>

using namespace std;

Memory::Memory() {
    int rows = 16;
    int cols = 16;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            memory[i][j] = "00";  
        }
    }
}

string Memory::getCell(string hexAddress) {
    ALU A;
    
    int decAddress = A.hexToDec(hexAddress);
    

    int row = decAddress / 16;  
    int col = decAddress % 16;  
   

    if (decAddress < 256 && decAddress >= 0) {
        
        return memory[row][col];
     
    } else {
        cout << "Invalid memory address\n";
        return "";
    }
}

void Memory::setCell(string hexAddress, string hexValue) {
    ALU A;
    int decAddress = A.hexToDec(hexAddress);

    int row = decAddress / 16;  
    int col = decAddress % 16;  

    if (decAddress < 256 && decAddress >= 0) {
         
            memory[row][col] = hexValue;  
        
      
    } else {
        cout << "Invalid memory address\n";
    }
}
void Memory::loadInstruction(Memory &M,string instructions, string address)
{
ALU alu;
    
    size_t startPos = 0;
    while (startPos < instructions.length())
    {
        size_t spacePos = instructions.find(' ', startPos);
        string instruction = (spacePos == string::npos) ? instructions.substr(startPos) : instructions.substr(startPos, spacePos - startPos);

        if (alu.isvalid(instruction))
        {
            M.setCell(address, instruction.substr(0, 2));
            address = alu.decToHex(alu.hexToDec(address) + 1);
            M.setCell(address, instruction.substr(2, 2));
            address = alu.decToHex(alu.hexToDec(address) + 1);
        }

        if (spacePos == string::npos)
            break;
        startPos = spacePos + 1;
    }
}
void Memory::printMemory()
{

       
        ALU A;
        cout << "=====================Memory=====================" << endl;

        cout << "   ";  
        for (int j = 0; j < 16; j++) {
            cout << A.decToHex(j) << "  ";  
        }
        cout << endl;

        for (int i = 0; i < 16; i++) {
            cout << A.decToHex(i) << "  ";  
            for (int j = 0; j < 16; j++) {
                cout << memory[i][j] << " ";  
            }
            cout << endl;
        }    
}
