#ifndef A1_T4_S28_20230171_2023188_20230577_MAIN_H
#define A1_T4_S28_20230171_2023188_20230577_MAIN_H

#include<string>
using namespace std;
class MainUI{
    private:
        //Machine machine;
        bool enterFileOrinstructions=true;
    public:

        bool getFileOrinstractions();
        void displayMenu();
        string inputFileName();
        string inputInstraction();
        string inputAddress();
        char inputChoice();
};
#endif