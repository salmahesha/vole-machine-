#ifndef A1_T4_S28_20230171_2023188_20230577_ALU_H
#define A1_T4_S28_20230171_2023188_20230577_ALU_H
#include<string>
#include "A1_T4_S28_20230171_20230188_20230577_Register.h"
#include "A1_T4_S28_20230171_20230188_20230577_MainUI.h"
using namespace std;
class ALU{
    public:
        int hexToDec(string hex);
        string decToHex(int dec);
        bool isvalid(string instruction);
        void add(string idx1,string idx2,string idx3,Register&R);
};
#endif