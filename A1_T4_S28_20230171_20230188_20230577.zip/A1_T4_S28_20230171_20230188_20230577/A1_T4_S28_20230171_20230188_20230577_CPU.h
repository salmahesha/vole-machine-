#ifndef A1_T4_S28_20230171_2023188_20230577_CPU_H
#define A1_T4_S28_20230171_2023188_20230577_CPU_H
#include<string>
#include <vector>
#include "A1_T4_S28_20230171_20230188_20230577_CU.h"
#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
using namespace std;
class CPU{
    private:
        string programCounter;
        string instructionRegister;
        ALU alu;
        CU cu;
    public:
       CPU();
       void setPC(string PC);
       string getPC();
       void runNextStep(Memory&M,Register &R,string address);
       void fetch(Memory&M);
       string decode();
       void execute(Register&R,Memory&M);
      
};
#endif 