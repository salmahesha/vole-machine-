#ifndef A1_T4_S28_20230171_20230188_20230577_CU_H
#define A1_T4_S28_20230171_20230188_20230577_CU_H
#include<string>
#include "A1_T4_S28_20230171_20230188_20230577_Register.h"
#include "A1_T4_S28_20230171_20230188_20230577_Memory.h"
using namespace std;
class CU{
    public:
        void load1(string idxReg,string stringMem ,Register&R,Memory&M);
        void load2 (string idxReg,string val,Register&R);
        void store (string idxReg1,string addmem,Register&R,Memory&M);
        void ADD(string idxReg1,string idxReg2,string idxReg3,Register&R);
        void move (string idxReg1,string idxReg2,Register&R);
        void jump(string idxReg,string stringMem ,Register&R);
        void halt();
};
#endif