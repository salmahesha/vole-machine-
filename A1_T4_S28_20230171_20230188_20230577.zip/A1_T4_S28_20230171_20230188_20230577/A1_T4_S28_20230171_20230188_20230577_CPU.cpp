#include "A1_T4_S28_20230171_20230188_20230577_CPU.h"
#include <vector>
#include <sstream>
#include <fstream>
#include "A1_T4_S28_20230171_20230188_20230577_MainUI.h"
#include <iostream>
#include <string>
#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
#include "A1_T4_S28_20230171_20230188_20230577_Memory.h"
#include "A1_T4_S28_20230171_20230188_20230577_CU.h"
using namespace std;

CPU::CPU()
{
    instructionRegister = "0000";
    programCounter = "0";
    
}
string CPU::getPC()
{
    return programCounter;
}


void CPU::runNextStep(Memory &M, Register &R, string address)
{
    programCounter=address;
    fetch(M);
    execute(R,M);
    if(M.getCell(alu.decToHex(alu.hexToDec(programCounter) + 2))=="00")
        {
        cout << "PC= " << alu.hexToDec(programCounter) << endl;
        cout << "IR= " << instructionRegister << endl;
        }
    else{
        programCounter = alu.decToHex(alu.hexToDec(programCounter) + 2);
            
        runNextStep(M,R,programCounter);
    }

}


void CPU::fetch(Memory &M)
{
      
        instructionRegister = M.getCell(programCounter);
        instructionRegister += M.getCell(alu.decToHex(alu.hexToDec(programCounter) +1));
       
}



string CPU::decode() {
   string opcode= instructionRegister.substr(0,2);
   string oprend=instructionRegister.substr(2,2);
   return opcode+oprend;

    
}

void CPU::execute(Register &R, Memory &M) {
    CU cu;
    ALU alu;
     string intmem = instructionRegister.substr(2, 2);

    switch (instructionRegister[0]) {
    case '1':
        cu.load1(string(1, instructionRegister[1]), intmem, R, M);
        break;
    case '2':
        cu.load2(string(1,instructionRegister[1]),intmem,R);
        break;
    case '3':
        cu.store(string(1,instructionRegister[1]),intmem,R,M);
        break;
    case '4':
        cu.move(string(1,instructionRegister[2]),string(1,instructionRegister[3]),R);
        break;
    case '5':
        cu.ADD(string(1,instructionRegister[1]),string(1,instructionRegister[3]),string(1,instructionRegister[2]),R);
        break;
    case '6':
        alu.add(string(1,instructionRegister[1]), string(1,instructionRegister[2]), string(1,instructionRegister[3]), R);

        break;
    case 'B':
        cu.jump(string(1,instructionRegister[1]),intmem,R);
        break;
    case 'C':
        cu.halt();
    default:
        break;
    }
}
