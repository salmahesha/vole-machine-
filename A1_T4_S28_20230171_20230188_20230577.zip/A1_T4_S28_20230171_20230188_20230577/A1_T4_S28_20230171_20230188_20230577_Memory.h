#ifndef A1_T4_S28_20230171_2023188_20230577_MEMORY_H
#define A1_T4_S28_20230171_2023188_20230577_MEMORY_H
#include<string>
#include <vector>

using namespace std;
class Memory{
    string memory[16][16];
   
    public:
    Memory();
        string getCell(string hexAddress);
        void setCell(string hexAddress, string hexValue);
        void loadInstruction(Memory &M,string instructions, string address);
        void printMemory();

      
};
#endif