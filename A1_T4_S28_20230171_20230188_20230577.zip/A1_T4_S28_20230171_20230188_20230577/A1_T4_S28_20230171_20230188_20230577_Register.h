#ifndef A1_T4_S28_20230171_2023188_20230577_REGISTER_H
#define A1_T4_S28_20230171_2023188_20230577_REGISTER_H
#include<string>
#include <vector>

using namespace std;
class Register{
    string memory[16];
    int Size;
    public:
        Register();
        string getCell(string address);
        void setCell(string address,string val);
        void printRegister();
};
#endif
