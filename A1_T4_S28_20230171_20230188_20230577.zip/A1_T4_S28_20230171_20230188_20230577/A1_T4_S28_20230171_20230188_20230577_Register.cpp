#include "A1_T4_S28_20230171_20230188_20230577_Register.h"
#include "A1_T4_S28_20230171_20230188_20230577_ALU.h"
//#include "Memory.cpp"
#include <iostream>

using namespace std;

Register::Register() {
    Size = 16; 
    for (int i = 0; i < Size; i++) {
        memory[i] = "00"; 
    }
}

string Register::getCell(string address) {
    ALU A;
    int hex =A.hexToDec(address);
    if (hex < Size && hex >= 0) {
        return memory[hex];
    
    }
}

void Register::setCell(string address, string val) {
    ALU A;
    int hex=A.hexToDec(address);
    if (hex < Size && hex >= 0) {
        memory[hex] = val;

       
    } else {
        cout << "Invalid register address\n";
    }
}

void Register::printRegister()
{
    ALU A;
     cout << "=====================Registers=====================" << endl;
        for (int i = 0; i < Size; i++) {
            cout <<"Register "<< A.decToHex(i) << "_________ " << memory[i] << endl;
        }
}
