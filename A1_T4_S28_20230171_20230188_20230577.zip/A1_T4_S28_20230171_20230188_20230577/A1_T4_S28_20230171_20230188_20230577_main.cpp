#include "A1_T4_S28_20230171_20230188_20230577_CPU.cpp"
#include "A1_T4_S28_20230171_20230188_20230577_Memory.cpp"
#include "A1_T4_S28_20230171_20230188_20230577_Register.cpp"
#include "A1_T4_S28_20230171_20230188_20230577_ALU.cpp"
#include "A1_T4_S28_20230171_20230188_20230577_CU.cpp"
#include "A1_T4_S28_20230171_20230188_20230577_MainUI.cpp"
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    MainUI ui;
    CPU cpu;
    Memory memory;
    Register reg;
    cout << "********** VOLE MACHINE **********\n" << endl;

    bool fromFile = ui.getFileOrinstractions();
    string address = ui.inputAddress();
    char choice;

    do {
        // Display the main menu and get user choice
        ui.displayMenu();
        choice = ui.inputChoice();

        switch (choice)
        {
        case 'A': // Execute instructions
            if (fromFile) {
                string fileName = ui.inputFileName();
                ifstream file(fileName);
                if (!file.is_open()) {
                    cerr << "Error: Unable to open file " << fileName << endl;
                    return 1;
                } else {
                    string line;
                    while (getline(file, line)) {
                        if (line == "C000")
                            break;
                        memory.loadInstruction(memory, line, address);
                        cpu.runNextStep(memory, reg, address);
                    }
                    file.close();
                }
            } else
{
    string allInstructions = "";
    while (true)
    {
        string instructions = ui.inputInstraction();
        if (instructions.empty()) {
            continue;
        }
        
        allInstructions += instructions + " ";

        if (instructions.find("C000") != string::npos) {
            break;
        }
    }

    istringstream instructionStream(allInstructions);

    string line;
    while (getline(instructionStream, line)) {
        memory.loadInstruction(memory, line, address);
        cpu.runNextStep(memory, reg, address);
    }

    ui.displayMenu();
}

        case 'B': // Display memory and registers
            memory.printMemory();
            reg.printRegister();
            break;

        case 'C': // Exit
            main();
            break;
        case 'D':
            cout<<"Exiting the program....."<<endl;
            return 1;
        default:
            cout << "Invalid choice! Please try again." << endl;
            break;
        }
    } while (choice != 'D'); 

    return 0;
}
